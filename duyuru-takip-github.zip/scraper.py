import json
import os
import re
import hashlib
from datetime import datetime, timezone, timedelta
from urllib.parse import urljoin
import urllib3
import requests
from bs4 import BeautifulSoup

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

TR_TZ = timezone(timedelta(hours=3))
NOW = datetime.now(TR_TZ)
TODAY_STR = NOW.strftime("%Y-%m-%d")

SOURCES = [
    # Spor Federasyonları
    {"id": "tvf", "tab": "spor", "name": "Voleybol (TVF)", "url": "https://tvf.org.tr/icerikler/tvf-duyurular"},
    {"id": "tvf-mhgk", "tab": "spor", "name": "Voleybol hakem (MHGK)", "url": "https://tvf.org.tr/icerikler/mhgk-duyurular/"},
    {"id": "badminton", "tab": "spor", "name": "Badminton (TBF)", "url": "https://www.badminton.org.tr/duyurular/"},
    {"id": "tyf", "tab": "spor", "name": "Yüzme (TYF)", "url": "https://www.tyf.gov.tr/haberler/"},
    {"id": "tyf-hakem", "tab": "spor", "name": "Yüzme hakem kursları", "url": "https://www.tyf.gov.tr/hakem-islemleri/kurslar.html"},
    {"id": "tmtf", "tab": "spor", "name": "Masa Tenisi (TMTF)", "url": "https://tmtf.gov.tr/duyurular"},
    {"id": "taf", "tab": "spor", "name": "Atletizm (TAF)", "url": "https://taf.org.tr/category/duyuru"},
    {"id": "bilardo-mhk", "tab": "spor", "name": "Bilardo hakem kurulu (MHK)", "url": "https://mhk.bilardo.gov.tr/"},
    {"id": "bilardo", "tab": "spor", "name": "Bilardo", "url": "https://www.bilardo.org.tr/duyurular.html"},
    {"id": "ordu-gsim", "tab": "spor", "name": "Ordu Gençlik ve Spor İl Müd.", "url": "https://ordu.gsb.gov.tr/"},
    # Barolar
    {"id": "giresun-baro", "tab": "barolar", "name": "Giresun Barosu", "url": "https://www.giresunbarosu.org.tr/Haberler"},
    {"id": "ordu-baro", "tab": "barolar", "name": "Ordu Barosu", "url": "https://www.ordubarosu.org.tr/TumHaberler"},
    # Üniversite
    {"id": "giresun-sbe", "tab": "universite", "name": "Giresun Üni. Sosyal Bilimler Enst.", "url": "https://sbe.giresun.edu.tr/tr/news"},
    # Sağlık Bakanlığı
    {"id": "yhgm", "tab": "saglik", "name": "Yönetim Hizmetleri Genel Müd.", "url": "https://yhgm.saglik.gov.tr/TR-10084/duyurular.html"},
    {"id": "giresun-ism", "tab": "saglik", "name": "Giresun İl Sağlık Müd.", "url": "https://giresunism.saglik.gov.tr/TR-22137/duyurular.html"},
    {"id": "sgb", "tab": "saglik", "name": "Strateji Geliştirme Bşk.", "url": "https://sgb.saglik.gov.tr/TR-59029/duyurular.html"},
    {"id": "sbsgm", "tab": "saglik", "name": "Sağlık Bilgi Sistemleri GM (SBSGM)", "url": "https://sbsgm.saglik.gov.tr/TR-1283/duyurular.html"},
    {"id": "khgm", "tab": "saglik", "name": "Kamu Hastaneleri GM (KHGM)", "url": "https://khgm.saglik.gov.tr/TR-39978/duyurular.html"},
    # Adalet / Bilirkişilik
    {"id": "bilirkisi", "tab": "adalet", "name": "Bilirkişilik Daire Başkanlığı", "url": "https://bilirkisilik.adalet.gov.tr/Home/TumHaberler/1"},
    {"id": "trabzon-bbk", "tab": "adalet", "name": "Trabzon Bilirkişilik Bölge Kurulu", "url": "https://trabzonbbk.adalet.gov.tr/Arsiv/duyuru"},
    {"id": "samsun-bbk", "tab": "adalet", "name": "Samsun Bilirkişilik Bölge Kurulu", "url": "https://samsunbbk.adalet.gov.tr/Arsiv/duyuru"},
    {"id": "bilirkisi-egitim", "tab": "adalet", "name": "Temel eğitim duyuruları", "url": "https://bilirkisilik.adalet.gov.tr/Home/SayfaDetay/egitim-kuruluslari02072020025435"},
    # Tayin
    {"id": "yhgm-bhg", "tab": "tayin", "name": "YHGM Bölge Hizmet Grupları", "url": "https://yhgm.saglik.gov.tr/TR-34970/bolge-hizmet-gruplari.html"},
    # TOKİ
    {"id": "toki-satis", "tab": "toki", "name": "TOKİ Satış Duyuruları", "url": "https://www.toki.gov.tr/satis/tr/duyurular"},
    {"id": "toki-haber", "tab": "toki", "name": "TOKİ Haberler", "url": "https://www.toki.gov.tr/haberler"},
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
}

SKIP_WORDS = {
    "anasayfa", "ana sayfa", "iletişim", "hakkımızda", "kurumsal", "duyurular",
    "haberler", "tümü", "devamı", "detay", "giriş", "menü", "arama", "english",
    "tarihçe", "mevzuat", "yönetim kurulu", "kurullar", "galeri", "videolar"
}

DATE_RE = re.compile(r"\b(\d{1,2})[./-](\d{1,2})[./-](20\d{2})\b")

def extract_date(text):
    m = DATE_RE.search(text or "")
    if not m:
        return None
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if 1 <= d <= 31 and 1 <= mo <= 12:
        return f"{y:04d}-{mo:02d}-{d:02d}"
    return None

def make_id(source_id, title, url):
    raw = f"{source_id}|{title.strip()}|{url.strip()}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]

def load_existing():
    if os.path.exists("data.json"):
        try:
            with open("data.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                return {it["id"]: it for it in data.get("items", []) if "id" in it}
        except Exception:
            pass
    return {}

def scrape_source(src):
    items = []
    try:
        resp = requests.get(src["url"], headers=HEADERS, timeout=25, verify=False)
        resp.raise_for_status()
        resp.encoding = resp.apparent_encoding or "utf-8"
        soup = BeautifulSoup(resp.text, "html.parser")

        for tag in soup(["nav", "header", "footer", "script", "style"]):
            tag.decompose()

        seen_urls = set()
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if not href or href.startswith(("#", "javascript:", "mailto:", "tel:")):
                continue
            full_url = urljoin(src["url"], href)
            if full_url in seen_urls or full_url.rstrip("/") == src["url"].rstrip("/"):
                continue

            title = " ".join(a.get_text(" ", strip=True).split())
            if len(title) < 18 or len(title) > 260:
                continue
            if title.lower() in SKIP_WORDS:
                continue

            parent_text = " ".join(a.parent.get_text(" ", strip=True).split()) if a.parent else title
            found_date = extract_date(title) or extract_date(parent_text)

            seen_urls.add(full_url)
            items.append({
                "id": make_id(src["id"], title, full_url),
                "tab": src["tab"],
                "source": src["id"],
                "title": title,
                "url": full_url,
                "date": found_date,
                "seen": NOW.isoformat()
            })
            if len(items) >= 25:
                break

        return items, {"ok": True, "count": len(items)}
    except Exception as e:
        return [], {"ok": False, "note": str(e)[:60]}

def main():
    existing = load_existing()
    src_status = {}
    new_count = 0

    for src in SOURCES:
        fetched, st = scrape_source(src)
        src_status[src["id"]] = st
        for it in fetched:
            if it["id"] in existing:
                old = existing[it["id"]]
                if not old.get("date") and it.get("date"):
                    old["date"] = it["date"]
            else:
                existing[it["id"]] = it
                new_count += 1

    # Son 45 günlük kayıtları tut
    cutoff = (NOW - timedelta(days=45)).strftime("%Y-%m-%d")
    all_items = [
        it for it in existing.values()
        if (it.get("date") or it.get("seen", "")[:10]) >= cutoff
    ]
    all_items.sort(key=lambda x: (x.get("date") or x.get("seen", "")[:10]), reverse=True)

    out = {
        "status": {
            "runAt": NOW.isoformat(),
            "newCount": new_count,
            "sources": src_status
        },
        "items": all_items
    }

    with open("data.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"Tamamlandı: {len(all_items)} toplam duyuru, {new_count} yeni duyuru.")

if __name__ == "__main__":
    main()
